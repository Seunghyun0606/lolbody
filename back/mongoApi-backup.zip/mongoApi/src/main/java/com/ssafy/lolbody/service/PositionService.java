package com.ssafy.lolbody.service;

import org.springframework.stereotype.Service;

@Service
public class PositionService {
	public String getPosition(String name, long gameId) {
		
		return null;
	}
}
